# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    2bd95d62481ba2b7004e865f8b3e1ee192b8457a

Visit <https://github.com/duddel/yourgamelib> for more information.