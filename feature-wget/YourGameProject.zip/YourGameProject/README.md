# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    4a088a5354aef506bccdc3f61dc09571166bf912

Visit <https://github.com/duddel/yourgamelib> for more information.