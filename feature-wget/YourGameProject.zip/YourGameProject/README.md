# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    5cc4782fe53372298f6beeb03685b2609a18c2d9

Visit <https://github.com/duddel/yourgamelib> for more information.