# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    5fd0841fa2c4273f691b9b4418307a9db32d1bde

Visit <https://github.com/duddel/yourgamelib> for more information.