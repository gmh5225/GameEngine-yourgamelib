# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    ae1eacfab0e2fb200b2d6791460df8aab66744b1

Visit <https://github.com/duddel/yourgamelib> for more information.