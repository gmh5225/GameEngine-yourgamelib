# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    cc329b11c6a3e7f3b3dd75f68b7ddbfc4f5a32f5

Visit <https://github.com/duddel/yourgamelib> for more information.