# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    19edb87c03c6365de1fe1a64d96efca821c762b5

Visit <https://github.com/duddel/yourgamelib> for more information.