# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    8c5606f50b868c9ffe2d57dff49b9908c4c9269c

Visit <https://github.com/duddel/yourgamelib> for more information.