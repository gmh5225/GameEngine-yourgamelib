# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    0cbf3c4bf65c56193b7ad238bfdcb32ae75badd3

Visit <https://github.com/duddel/yourgamelib> for more information.