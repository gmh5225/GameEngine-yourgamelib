# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    685a6bf3313fd0b91e139fd05e3b36552dd32575

Visit <https://github.com/duddel/yourgamelib> for more information.