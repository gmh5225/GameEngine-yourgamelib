# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    02b2283eb61045792c11704f2d635681a637f00f

Visit <https://github.com/duddel/yourgamelib> for more information.