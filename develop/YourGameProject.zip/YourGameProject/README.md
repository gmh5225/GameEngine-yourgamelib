# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    6a2d7638942752ae425dca50cb84b2ffec8f589a

Visit <https://github.com/duddel/yourgamelib> for more information.