# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    47e54a42dbf58b8519693c2f4a3b4168d135485a

Visit <https://github.com/duddel/yourgamelib> for more information.