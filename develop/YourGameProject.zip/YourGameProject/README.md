# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    8d5264d6168b7b8b2fa28e6e0af2308352a2ddb8

Visit <https://github.com/duddel/yourgamelib> for more information.