# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    08fd59916ae42e96e1c1bfd8722cc23ce178a907

Visit <https://github.com/duddel/yourgamelib> for more information.