# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    f5ce9ad2ede52afe5eed251cecb2920046c9fb82

Visit <https://github.com/duddel/yourgamelib> for more information.