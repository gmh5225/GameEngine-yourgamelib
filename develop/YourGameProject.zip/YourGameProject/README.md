# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    ae5383f3861cf33ac9061b0bb28ada52e45007c4

Visit <https://github.com/duddel/yourgamelib> for more information.