# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    edf109f3bf300d8e717c6a1975b3c06356116ba8

Visit <https://github.com/duddel/yourgamelib> for more information.