# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    9a28eff3d8287fff50ca24dafae4748f282d5a05

Visit <https://github.com/duddel/yourgamelib> for more information.