# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    75f4a0134704396a57112d3a8db782c5ee0027a4

Visit <https://github.com/duddel/yourgamelib> for more information.