# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    92f44a9fd6ee9daeafb029509a46827533ee9e1d

Visit <https://github.com/duddel/yourgamelib> for more information.