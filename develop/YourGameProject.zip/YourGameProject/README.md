# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    98dac712b367512465f9762fbc5143aacc6037d7

Visit <https://github.com/duddel/yourgamelib> for more information.