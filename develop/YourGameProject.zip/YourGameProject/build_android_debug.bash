#!/bin/bash

cd android
gradle assembleDebug
cd -
