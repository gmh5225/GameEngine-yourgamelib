# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    934d1fbcc8a7f09bc5f29f5430388840106cb566

Visit <https://github.com/duddel/yourgamelib> for more information.