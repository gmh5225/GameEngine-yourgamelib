# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    dbeb5200696244964321ecbfddbb0f9dc0f19cf7

Visit <https://github.com/duddel/yourgamelib> for more information.