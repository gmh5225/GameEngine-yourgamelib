# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    ee52d226b200a696ed464ee9391aaa5f13d91078

Visit <https://github.com/duddel/yourgamelib> for more information.