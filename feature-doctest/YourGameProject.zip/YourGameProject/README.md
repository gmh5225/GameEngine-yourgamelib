# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    24ca3211361841c6237a5ad95344181418a455ef

Visit <https://github.com/duddel/yourgamelib> for more information.