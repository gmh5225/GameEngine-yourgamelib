# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    270541b3981984d69d7da6b90e0d1e38244a3c1b

Visit <https://github.com/duddel/yourgamelib> for more information.