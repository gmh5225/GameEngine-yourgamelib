# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    d36aa7e381b69970b17b57dc06adf51a7341e89a

Visit <https://github.com/duddel/yourgamelib> for more information.