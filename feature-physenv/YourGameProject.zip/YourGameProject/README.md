# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    d0e2d8874553ac0d32a639dacb0479d9513a7925

Visit <https://github.com/duddel/yourgamelib> for more information.