# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    1929c876eebf4397d8e5f046eec55d5edb69b5a3

Visit <https://github.com/duddel/yourgamelib> for more information.