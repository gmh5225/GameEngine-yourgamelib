# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    0073d1c56b3001e708a4277f56092d436b406eed

Visit <https://github.com/duddel/yourgamelib> for more information.