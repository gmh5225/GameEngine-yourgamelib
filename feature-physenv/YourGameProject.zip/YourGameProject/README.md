# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    f4c50a1d086fa168c6fd88506587ab7312f42dd7

Visit <https://github.com/duddel/yourgamelib> for more information.