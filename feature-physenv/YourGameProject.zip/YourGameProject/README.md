# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    ec320288dab4b5edde1ca5bb20919cbd3aeee1c5

Visit <https://github.com/duddel/yourgamelib> for more information.