# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    e6ad68d04edb5e709a99d8122cc9652b1d3b90a9

Visit <https://github.com/duddel/yourgamelib> for more information.