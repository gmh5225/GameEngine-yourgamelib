# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    b98905a4d10c3d28b3d4cdff6d614f16690d4a84

Visit <https://github.com/duddel/yourgamelib> for more information.