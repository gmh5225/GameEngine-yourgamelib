# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    79ef3bcc4565312994db8b8476d86c0aea770a94

Visit <https://github.com/duddel/yourgamelib> for more information.