# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    32fcd1fa616b81213b4e32fa58a5176c2024007d

Visit <https://github.com/duddel/yourgamelib> for more information.