# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    fe477f908c8cceefbbf3fd19ebde1e268306cfcd

Visit <https://github.com/duddel/yourgamelib> for more information.