# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    7ee70da94c4b8bcc8e58b508a00c988f2da7d4fe

Visit <https://github.com/duddel/yourgamelib> for more information.