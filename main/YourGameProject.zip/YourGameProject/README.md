# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    dd89ceab0d2b1f46d4c082b410d8eaa2623e81e2

Visit <https://github.com/duddel/yourgamelib> for more information.