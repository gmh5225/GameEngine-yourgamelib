# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    284c1d08c00c9a72061d2ad6ced03b4d57b7e431

Visit <https://github.com/duddel/yourgamelib> for more information.