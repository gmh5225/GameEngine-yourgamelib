# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    d5d9b0b7a2300a8dc9cd4e3630cb20350b429702

Visit <https://github.com/duddel/yourgamelib> for more information.