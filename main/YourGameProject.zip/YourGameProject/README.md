# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    461fafd724bc6e204f8c8142ad53d067c5d98546

Visit <https://github.com/duddel/yourgamelib> for more information.