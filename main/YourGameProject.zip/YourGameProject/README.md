# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    4643f27d502c05c69b89d182a890c2e86ada8c6f

Visit <https://github.com/duddel/yourgamelib> for more information.