# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    a8d44efbf5d55131b9c169a79d327642e0a1dca9

Visit <https://github.com/duddel/yourgamelib> for more information.