# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    862e5a89b3b14f2e7ff8623ef236857265b38ced

Visit <https://github.com/duddel/yourgamelib> for more information.