# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    3078acf0a5bfcee45ee07dd2a8fc4526479db724

Visit <https://github.com/duddel/yourgamelib> for more information.