# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    fc0cdd91ac2ca0c12433fe87c3be0fb3c9868cb9

Visit <https://github.com/duddel/yourgamelib> for more information.