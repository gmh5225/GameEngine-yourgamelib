# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    06d229bc4b0113cef559a453a754c1aa1ababba4

Visit <https://github.com/duddel/yourgamelib> for more information.