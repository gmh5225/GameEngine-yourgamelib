# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    1206c8377008c123a3526b162f13976e90687579

Visit <https://github.com/duddel/yourgamelib> for more information.