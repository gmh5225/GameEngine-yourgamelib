# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    2b1f7672ee18c2ce6aafe8e1c588c5a1a40cd091

Visit <https://github.com/duddel/yourgamelib> for more information.