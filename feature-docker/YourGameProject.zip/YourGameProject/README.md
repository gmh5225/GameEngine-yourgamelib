# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    d6b0cb50ade2daee100aea385305e61a73746da8

Visit <https://github.com/duddel/yourgamelib> for more information.