# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    049d17d5d9250878ae9412dd4eb7b545c6431023

Visit <https://github.com/duddel/yourgamelib> for more information.