# YourGameProject

This is a `YourGameLib` project, initialized from commit:

    97f21f1ec9c41d039dcfd05519bf8eb5a56fad9f

Visit <https://github.com/duddel/yourgamelib> for more information.